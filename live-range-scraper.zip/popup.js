// Popup script
let allMessages = [];
let isRecording = false;

// DOM elements
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const clearBtn = document.getElementById('clearBtn');
const searchInput = document.getElementById('searchInput');
const results = document.getElementById('results');
const messageCount = document.getElementById('messageCount');
const resultsCount = document.getElementById('resultsCount');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const exportBtn = document.getElementById('exportBtn');
const refreshBtn = document.getElementById('refreshBtn');

// Initialize - script is at bottom of <body>, DOM is already ready
// DOMContentLoaded has already fired by this point, so call directly
loadMessages();
checkRecordingStatus();
setupEventListeners();

function setupEventListeners() {
  startBtn.addEventListener('click', startRecording);
  stopBtn.addEventListener('click', stopRecording);
  clearBtn.addEventListener('click', clearData);
  searchInput.addEventListener('input', handleSearch);
  exportBtn.addEventListener('click', exportData);
  refreshBtn.addEventListener('click', loadMessages);
}

function checkRecordingStatus() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (chrome.runtime.lastError) return;
    if (tabs[0] && tabs[0].url && tabs[0].url.includes('ivasms.com')) {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'getStatus' }, (response) => {
        if (chrome.runtime.lastError) return; // Content script not loaded yet, that's OK
        if (response && response.isRecording) {
          updateUIStatus(true);
        }
      });
    }
  });
}

function startRecording() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (chrome.runtime.lastError) {
      showNotification('Could not access tab info', 'error');
      return;
    }
    if (tabs[0] && tabs[0].url && tabs[0].url.includes('ivasms.com')) {
      // ① Signal via storage first — content script reacts instantly
      chrome.storage.local.set({ recordingState: true });

      // ② Update UI immediately
      updateUIStatus(true);
      showNotification('Recording started', 'success');

      // ③ Also send message (ensures content script is injected if needed)
      chrome.tabs.sendMessage(tabs[0].id, { action: 'startRecording' }, (response) => {
        if (chrome.runtime.lastError) {
          // Content script not loaded — inject it
          chrome.scripting.executeScript(
            { target: { tabId: tabs[0].id }, files: ['content.js'] },
            () => {
              if (chrome.runtime.lastError) {
                showNotification('Could not inject. Please refresh the ivasms.com page.', 'error');
                updateUIStatus(false);
                chrome.storage.local.set({ recordingState: false });
                return;
              }
              // Re-signal after injection
              setTimeout(() => chrome.storage.local.set({ recordingState: true }), 100);
            }
          );
        }
      });
    } else {
      showNotification('Please navigate to ivasms.com portal', 'error');
    }
  });
}

function stopRecording() {
  // ① Update UI instantly — zero delay
  updateUIStatus(false);

  // ② Write kill-switch to storage IMMEDIATELY — content script reacts via
  //    chrome.storage.onChanged before any message round-trip even starts
  chrome.storage.local.set({ recordingState: false });

  // ③ Send message as a backup (handles edge cases like content script restart)
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { action: 'stopRecording' }, () => {
      chrome.runtime.lastError; // suppress unchecked error warning
    });
  });

  showNotification('Recording stopped', 'info');
}

function updateUIStatus(recording) {
  isRecording = recording;
  
  if (recording) {
    statusDot.classList.add('recording');
    statusText.textContent = 'Recording';
    startBtn.disabled = true;
    stopBtn.disabled = false;
  } else {
    statusDot.classList.remove('recording');
    statusText.textContent = 'Not Recording';
    startBtn.disabled = false;
    stopBtn.disabled = true;
  }
}

function loadMessages() {
  chrome.storage.local.get(['smsData'], (result) => {
    allMessages = result.smsData || [];
    messageCount.textContent = allMessages.length;
    displayMessages(allMessages);
  });
}

function displayMessages(messages) {
  resultsCount.textContent = messages.length;
  
  if (messages.length === 0) {
    results.innerHTML = `
      <div class="empty-state">
        <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
          <line x1="9" y1="9" x2="15" y2="15"></line>
          <line x1="15" y1="9" x2="9" y2="15"></line>
        </svg>
        <p>No messages captured yet.</p>
        <p class="hint">Click "Start Recording" to begin capturing data.</p>
      </div>
    `;
    return;
  }
  
  // Reverse to show newest first
  const sortedMessages = [...messages].reverse();
  
  results.innerHTML = sortedMessages.map((msg, index) => {
    return createMessageHTML(msg, index);
  }).join('');
}

function createMessageHTML(msg, index) {
  // Handle different data structures
  let terminationId = '';
  let testNumber = '';
  let sender = '';
  let message = '';
  let time = '';
  
  if (typeof msg === 'object') {
    // Extract data based on common patterns
    testNumber = msg.phone || msg.number || msg.to || msg.testNumber || '';
    // FROM field comes from API as 'sid', 'sender', 'from', 'senderid', etc.
    sender = msg.sid || msg.sender || msg.from || msg.senderId || msg.senderid || '';
    message = msg.message || msg.text || msg.content || msg.body || '';
    time = msg.receivedAt || msg.timestamp || msg.time || msg.capturedAt || new Date().toLocaleString();
    terminationId = msg.terminationId || msg.termination || msg.country || '';
    
    // If message contains all data in one field, try to parse it
    if (!testNumber && message) {
      const fullText = message;
      // Try to extract from patterns like "EGYPT 19907 201064477960"
      const match = fullText.match(/^([A-Z\s]+)\s+(\d+)\s+(\d+)/);
      if (match) {
        terminationId = match[1].trim() + ' ' + match[2];
        testNumber = match[3];
        // Remove the parsed part from message
        message = fullText.substring(match[0].length).trim();
      }
    }
    
    // If still no clear structure, try rawHTML or textContent
    if (!testNumber && (msg.rawHTML || msg.textContent)) {
      const text = msg.textContent || msg.rawHTML || '';
      const match = text.match(/^([A-Z\s]+)\s+(\d+)\s+(\d+)/);
      if (match) {
        terminationId = match[1].trim() + ' ' + match[2];
        testNumber = match[3];
        message = text.substring(match[0].length).trim();
      } else {
        message = text;
      }
    }
    
    // If we still don't have data, stringify the object
    if (!testNumber && !message) {
      message = JSON.stringify(msg);
    }
  } else {
    message = String(msg);
    time = new Date().toLocaleString();
  }
  
  // Apply search highlighting only to text content, not HTML
  const searchTerm = searchInput.value.trim();
  let displayTerminationId = terminationId;
  let displayTestNumber = testNumber;
  let displaySender = sender;
  let displayMessage = message;
  
  if (searchTerm) {
    displayTerminationId = highlightTextOnly(terminationId, searchTerm);
    displayTestNumber = highlightTextOnly(testNumber, searchTerm);
    displaySender = highlightTextOnly(sender, searchTerm);
    displayMessage = highlightTextOnly(message, searchTerm);
  }
  
  return `
    <div class="message-item" data-index="${index}">
      <div class="message-header-row">
        <div class="message-field-inline">
          <span class="field-label">TERMINATION ID:</span> ${displayTerminationId || 'N/A'}
        </div>
        <div class="message-time">${escapeHtml(time)}</div>
      </div>
      <div class="message-field">
        <span class="field-label">TEST NUMBER:</span> ${displayTestNumber || 'N/A'}
      </div>
      <div class="message-field">
        <span class="field-label">FROM:</span> ${displaySender || ''}
      </div>
      <div class="message-content">${displayMessage}</div>
    </div>
  `;
}

function highlightTextOnly(text, searchTerm) {
  if (!text || !searchTerm) return escapeHtml(text);
  
  // First escape HTML to prevent any HTML injection
  const escaped = escapeHtml(text);
  
  try {
    // Simple case-insensitive search (removed regex and case-sensitive options)
    const flags = 'gi';
    const regex = new RegExp(escapeRegex(searchTerm), flags);
    return escaped.replace(regex, match => `<span class="highlight">${match}</span>`);
  } catch (e) {
    return escaped;
  }
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function handleSearch() {
  const searchTerm = searchInput.value.trim();
  
  if (!searchTerm) {
    displayMessages(allMessages);
    return;
  }
  
  try {
    const filtered = allMessages.filter(msg => {
      // Convert entire message object to searchable text
      const searchableText = JSON.stringify(msg).toLowerCase();
      const term = searchTerm.toLowerCase();
      return searchableText.includes(term);
    });
    
    displayMessages(filtered);
  } catch (e) {
    console.error('Search error:', e);
    displayMessages(allMessages);
  }
}

function clearData() {
  if (confirm('Are you sure you want to clear all captured SMS data? This cannot be undone.')) {
    chrome.storage.local.set({ smsData: [] }, () => {
      allMessages = [];
      loadMessages();
      showNotification('All data cleared', 'info');
    });
  }
}

function exportData() {
  if (allMessages.length === 0) {
    showNotification('No data to export', 'error');
    return;
  }
  
  // Create CSV content
  const headers = ['Termination ID', 'Test Number', 'FROM (SID)', 'Message', 'Date/Time', 'Captured At'];
  const csvRows = [headers.join(',')];
  
  allMessages.forEach(msg => {
    const terminationId = msg.terminationId || msg.termination || msg.country || '';
    const testNumber = msg.phone || msg.number || msg.to || msg.testNumber || '';
    const sender = msg.sid || msg.sender || msg.from || msg.senderId || msg.senderid || '';
    const message = msg.message || msg.text || msg.content || msg.body || '';
    const time = msg.receivedAt || msg.timestamp || msg.time || '';
    const capturedAt = msg.capturedAt || '';
    
    // Escape CSV values (handle commas, quotes, newlines)
    const escapeCsv = (val) => {
      if (val === null || val === undefined) return '';
      const str = String(val);
      // If contains comma, newline, or quote, wrap in quotes and escape quotes
      if (str.includes(',') || str.includes('\n') || str.includes('"')) {
        return '"' + str.replace(/"/g, '""') + '"';
      }
      return str;
    };
    
    const row = [
      escapeCsv(terminationId),
      escapeCsv(testNumber),
      escapeCsv(sender),
      escapeCsv(message),
      escapeCsv(time),
      escapeCsv(capturedAt)
    ].join(',');
    
    csvRows.push(row);
  });
  
  const csvContent = csvRows.join('\n');
  const dataBlob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
  const filename = `sms-data-${timestamp}.csv`;
  
  // Create a download link
  const url = URL.createObjectURL(dataBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  
  document.body.appendChild(a);
  a.click();
  
  // Clean up
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
  
  showNotification(`Exported ${allMessages.length} messages to CSV`, 'success');
}

function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
    color: white;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    z-index: 10000;
    animation: slideIn 0.3s ease-out;
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease-out';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// Listen for updates from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'dataUpdated') {
    loadMessages();
  } else if (request.action === 'recordingStarted') {
    updateUIStatus(true);
  } else if (request.action === 'recordingStopped') {
    updateUIStatus(false);
  }
});

// Add animation styles
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }
`;
document.head.appendChild(style);
