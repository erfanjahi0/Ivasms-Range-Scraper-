// Content script for scraping SMS data
let isRecording = false;

// ─── INSTANT KILL SWITCH via storage listener ────────────────────────────────
// Reacts the moment popup writes recordingState, no message round-trip needed
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.recordingState) {
    const newState = changes.recordingState.newValue;
    if (newState === false && isRecording) {
      isRecording = false;
      stopDOMMonitoring();
      console.log('🛑 Instant stop via storage signal');
    } else if (newState === true && !isRecording) {
      isRecording = true;
      startDOMMonitoring();
      console.log('▶️ Instant start via storage signal');
    }
  }
});

// ─── Message listener (backup / status queries) ───────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startRecording') {
    startRecording();
    sendResponse({ status: 'started' });
  } else if (request.action === 'stopRecording') {
    stopRecording();
    sendResponse({ status: 'stopped' });
  } else if (request.action === 'getStatus') {
    sendResponse({ isRecording: isRecording });
  }
  return true;
});

function startRecording() {
  if (isRecording) return;
  isRecording = true;
  console.log('SMS Scraper: Recording started');
  startDOMMonitoring();
  chrome.runtime.sendMessage({ action: 'recordingStarted' });
}

function stopRecording() {
  if (!isRecording) return;
  isRecording = false;
  console.log('SMS Scraper: Recording stopped');
  stopDOMMonitoring();
  chrome.runtime.sendMessage({ action: 'recordingStopped' });
}

// ─── DOM Monitoring ───────────────────────────────────────────────────────────
let domObserver = null;

function startDOMMonitoring() {
  if (domObserver) return;

  domObserver = new MutationObserver((mutations) => {
    if (!isRecording) return; // guard: stop firing even if observer hasn't disconnected yet

    for (const mutation of mutations) {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;

        const smsElements = [];
        if (node.matches && (node.matches('tr') || node.matches('.sms-row') || node.matches('[data-sms]'))) {
          smsElements.push(node);
        }
        if (node.querySelectorAll) {
          smsElements.push(...Array.from(node.querySelectorAll('tr, .sms-row, [data-sms]')));
        }

        smsElements.forEach(element => {
          const smsData = extractSMSFromElement(element);
          if (smsData) saveSMSData(smsData);
        });
      });
    }
  });

  domObserver.observe(document.body, { childList: true, subtree: true });
  console.log('✅ DOM monitor started');
}

function stopDOMMonitoring() {
  if (domObserver) {
    domObserver.disconnect();
    domObserver = null;
    console.log('🛑 DOM monitor stopped');
  }
}

// ─── Element extractor ────────────────────────────────────────────────────────
function extractSMSFromElement(element) {
  try {
    const cells = element.querySelectorAll('td');

    if (cells.length >= 2) {
      const cellTexts = Array.from(cells).map(c => c.textContent?.trim() || '');
      let terminationId = '', testNumber = '', sender = '', message = '';

      if (cellTexts[0]) {
        const match = cellTexts[0].match(/^([A-Z\s]+)\s+(\d+)$/);
        if (match) {
          terminationId = cellTexts[0];
          testNumber    = cellTexts[1] || '';
          sender        = cellTexts[2] || '';
          message       = cellTexts.slice(3).join(' ');
        } else {
          const fullMatch = cellTexts[0].match(/^([A-Z\s]+)\s+(\d+)\s+(\d+)/);
          if (fullMatch) {
            terminationId = `${fullMatch[1].trim()} ${fullMatch[2]}`;
            testNumber    = fullMatch[3];
            sender        = cellTexts[1] || '';
            message       = cellTexts.slice(2).join(' ');
          } else {
            testNumber = cellTexts[0];
            sender     = cellTexts[1];
            message    = cellTexts.slice(2).join(' ');
          }
        }
      }

      return {
        terminationId, testNumber,
        sid: sender, sender, message,
        timestamp: new Date().toISOString(),
        receivedAt: new Date().toLocaleString(),
        rawHTML: element.innerHTML
      };
    } else {
      const text = element.textContent?.trim();
      if (text && text.length > 5) return parseMessageString(text);
    }
  } catch (e) {
    console.error('Error extracting SMS:', e);
  }
  return null;
}

// ─── Save ─────────────────────────────────────────────────────────────────────
function saveSMSData(data) {
  if (!isRecording) return; // hard gate — checked synchronously before any async work

  chrome.storage.local.get(['smsData'], (result) => {
    if (!isRecording) return; // re-check after async storage read

    const existingData = result.smsData || [];
    let newData = [];

    if (Array.isArray(data)) {
      newData = data.flat();
    } else if (data && typeof data === 'object') {
      const key = ['data','messages','sms','results','items'].find(k => Array.isArray(data[k]));
      newData = key ? data[key] : [data];
    } else {
      newData = [data];
    }

    newData = newData.map(item => {
      if (typeof item === 'string') return parseMessageString(item);
      if (typeof item === 'object') return { ...item, capturedAt: item.capturedAt || new Date().toISOString() };
      return item;
    }).filter(Boolean);

    if (!isRecording) return; // one more check before writing

    const updatedData = [...existingData, ...newData].slice(-10000);

    chrome.storage.local.set({ smsData: updatedData }, () => {
      console.log(`✅ Captured ${newData.length} new messages. Total: ${updatedData.length}`);
      chrome.runtime.sendMessage({ action: 'dataUpdated', count: updatedData.length, newCount: newData.length });
    });
  });
}

// ─── Fetch interceptor ────────────────────────────────────────────────────────
(function() {
  const originalFetch = window.fetch;

  window.fetch = async function(...args) {
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
    const isTarget = url.includes('/portal/live/test_sms') || url.includes('test_sms');

    // Snapshot recording state at request time
    const wasRecordingAtRequestTime = isRecording && isTarget;

    if (wasRecordingAtRequestTime) console.log('🎯 Target fetch detected:', url);

    const response = await originalFetch.apply(this, args);

    if (wasRecordingAtRequestTime) {
      response.clone().text().then(text => {
        // ✅ CRITICAL: re-check isRecording AFTER await — if stopped in the meantime, discard
        if (!isRecording) {
          console.log('⏹ Fetch response discarded — recording stopped before response arrived');
          return;
        }
        try {
          const jsonData = JSON.parse(text);
          console.log('📨 Fetch captured:', jsonData);
          saveSMSData(jsonData);
        } catch (e) {
          saveSMSData({ rawData: text, timestamp: new Date().toISOString() });
        }
      }).catch(err => console.error('❌ Fetch capture error:', err));
    }

    return response;
  };

  console.log('✅ Fetch interceptor installed');
})();

// ─── XHR interceptor ─────────────────────────────────────────────────────────
(function() {
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._url = url;
    this._method = method;
    return originalOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(...args) {
    if (this._url && (this._url.includes('/portal/live/test_sms') || this._url.includes('test_sms'))) {
      // Snapshot state at send time
      const wasRecordingAtSendTime = isRecording;
      console.log('🎯 Target XHR detected:', this._url);

      this.addEventListener('load', function() {
        // ✅ CRITICAL: re-check isRecording when response arrives
        if (!wasRecordingAtSendTime || !isRecording) {
          console.log('⏹ XHR response discarded — recording stopped');
          return;
        }
        try {
          const data = JSON.parse(this.responseText);
          console.log('📨 XHR captured:', data);
          saveSMSData(data);
        } catch (e) {
          saveSMSData({ rawData: this.responseText, timestamp: new Date().toISOString(), url: this._url });
        }
      });
    }
    return originalSend.apply(this, args);
  };

  console.log('✅ XHR interceptor installed');
})();

console.log('🚀 SMS Scraper: Ready');
