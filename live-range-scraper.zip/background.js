// Background service worker
let recordingState = {
  isRecording: false,
  messageCount: 0
};

// Listen for messages from content script and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'recordingStarted') {
    recordingState.isRecording = true;
    updateBadge();
  } else if (request.action === 'recordingStopped') {
    recordingState.isRecording = false;
    updateBadge();
  } else if (request.action === 'dataUpdated') {
    recordingState.messageCount = request.count || 0;
    updateBadge();
  }
  
  sendResponse({ status: 'received' });
  return true;
});

// Update extension badge
function updateBadge() {
  if (recordingState.isRecording) {
    chrome.action.setBadgeText({ text: '●' });
    chrome.action.setBadgeBackgroundColor({ color: '#e74c3c' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Initialize badge on startup
chrome.runtime.onStartup.addListener(() => {
  updateBadge();
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('SMS Scraper extension installed');
  updateBadge();
});

// Keep service worker alive
setInterval(() => {
  chrome.storage.local.get(['smsData'], (result) => {
    recordingState.messageCount = (result.smsData || []).length;
  });
}, 30000);
