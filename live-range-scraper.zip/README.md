# SMS Live Scraper - Chrome Extension

A Chrome extension to scrape and search live SMS data from the ivasms.com portal with start/stop recording functionality.

## Features

- ✅ **Start/Stop Recording**: Control when to capture SMS data
- ⚡ **Real-time Capture**: Instant data capture as it arrives (no delays!)
- 🔍 **Advanced Search**: Search through captured messages with regex support
- 💾 **Export Data**: Export all captured data to JSON format
- 📊 **Live Updates**: Immediate message capture and display
- 🎨 **Clean UI**: Modern, intuitive interface
- 🔐 **Privacy**: All data stored locally in your browser

## Installation

### Method 1: Load Unpacked Extension (Development)

1. **Download or clone this repository**

2. **Open Chrome Extensions page**
   - Navigate to `chrome://extensions/`
   - Or click Menu → More Tools → Extensions

3. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner

4. **Load the extension**
   - Click "Load unpacked"
   - Select the `sms-scraper-extension` folder
   - The extension icon should appear in your toolbar

### Method 2: Package as CRX (Optional)

1. Go to `chrome://extensions/`
2. Enable Developer Mode
3. Click "Pack extension"
4. Select the extension directory
5. Share the generated `.crx` file

## Usage

### Starting Recording

1. **Navigate to ivasms.com portal**
   - Open any page under `https://www.ivasms.com/portal/live/`

2. **Click the extension icon** in Chrome toolbar

3. **Click "Start Recording"**
   - The status indicator will turn red and show "Recording"
   - Messages will be captured automatically

4. **Data is captured instantly when:**
   - The page makes requests to the `test_sms` endpoint (Fetch/XHR interception)
   - New SMS data appears in the DOM (MutationObserver)
   - **Zero delay** - data is captured the moment it arrives!

### Searching Messages

1. **Use the search box** to filter messages
   - Search by phone number, sender, or message content
   - Real-time filtering as you type

2. **Search Options:**
   - **Case Sensitive**: Match exact letter casing
   - **Regex**: Use regular expressions for advanced patterns

### Managing Data

- **Stop Recording**: Click "Stop Recording" to pause capture
- **Clear Data**: Remove all captured messages (confirmation required)
- **Export**: Download all data as JSON file
- **Refresh**: Reload messages from storage

## Technical Details

### Data Storage

- Messages stored in `chrome.storage.local`
- Maximum 10,000 messages retained (oldest removed first)
- No external server communication
- Data persists until manually cleared

### Data Interception Methods

The extension uses multiple real-time methods to capture SMS data instantly:

1. **Fetch API Interception**: Captures AJAX requests to `test_sms` endpoint in real-time
2. **XMLHttpRequest Monitoring**: Fallback for XHR requests (instant capture)
3. **MutationObserver**: Detects and captures new DOM elements as they're added
4. **Zero-delay architecture**: All methods trigger immediately when data arrives

### Permissions

- `storage`: Save captured SMS data locally
- `activeTab`: Access current tab for scraping
- `host_permissions`: Only works on ivasms.com domain

## File Structure

```
sms-scraper-extension/
├── manifest.json           # Extension configuration
├── popup.html             # Extension popup interface
├── popup.css              # Popup styles
├── popup.js               # Popup logic
├── content.js             # Content script for scraping
├── background.js          # Service worker
├── icons/                 # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md              # This file
```

## Troubleshooting

### Debugging

The extension includes detailed console logging. To debug:

1. **Open DevTools** (F12) on the ivasms.com page
2. **Go to Console tab**
3. **Start recording** in the extension
4. **Look for these logs:**
   - `🌐 Fetch request:` - Shows all network requests
   - `🎯 Target URL detected!` - Confirms the extension found the SMS endpoint
   - `📨 Real-time capture SUCCESS:` - Shows captured data
   - `⚠️ Data received but recording is OFF` - Recording not started

If you see `🌐 Fetch request:` logs but never see `🎯 Target URL detected!`, the URL pattern might be different. Check what URLs are being called and update the code.

### Extension Not Working

1. **Check the URL**: Extension only works on `ivasms.com/portal/live/*` pages
2. **Reload the extension**: Go to `chrome://extensions/` and click reload
3. **Check console**: Open DevTools (F12) and look for errors
4. **Verify permissions**: Ensure extension has required permissions

### No Data Being Captured

1. **Start recording first**: Click "Start Recording" button
2. **Check network activity**: Ensure the page is making requests to `test_sms`
3. **Inspect DOM structure**: The page structure may have changed
4. **Check console logs**: Look for "SMS Scraper" messages in DevTools

### Search Not Working

1. **Disable regex if using special characters**: Uncheck "Regex" option
2. **Try case-insensitive search**: Uncheck "Case sensitive"
3. **Check for typos**: Verify search term spelling

## Customization

### Adjusting Storage Limit

Edit `content.js`, look for `slice(-10000)`:
```javascript
// Change from 10000 to your preferred limit
const updatedData = [...existingData, ...newData].slice(-10000);
```

### Modifying DOM Selectors

If the website structure changes, update selectors in `content.js` in the `extractSMSFromElement` function:
```javascript
// Update table cell selectors to match the site's structure
const cells = element.querySelectorAll('td');
```

## Privacy & Security

- **No data transmission**: All data stays in your browser
- **Local storage only**: Uses Chrome's local storage API
- **Domain restricted**: Only runs on ivasms.com
- **Manual control**: You control when recording starts/stops

## Limitations

- Maximum 10,000 messages stored (configurable)
- Storage quota: ~5MB for extension data (Chrome limit)
- Only works when browser is open and extension is active
- Requires page to load data via fetch/XHR or visible DOM

## Contributing

To improve this extension:

1. Fork the repository
2. Make your changes
3. Test thoroughly on the target website
4. Submit a pull request

## License

This extension is provided as-is for personal use.

## Support

For issues or questions:
- Check the browser console for error messages
- Review the troubleshooting section
- Inspect network requests in DevTools

## Changelog

### Version 1.0.2 (URL Fix + Debug)
- 🔧 **Fixed endpoint URL**: Now correctly monitors `/portal/live/test_sms`
- 🐛 Added detailed debug logging to console
- 📊 Shows all network requests for troubleshooting
- ✅ Logs when target URL is detected and captured

### Version 1.0.1 (Performance Update)
- ⚡ **INSTANT CAPTURE**: Removed polling delays - data captured in real-time
- Added MutationObserver for immediate DOM-based capture
- Optimized fetch/XHR interception for zero-delay processing
- Real-time notification counter for new messages
- Improved data structure handling for various API responses

### Version 1.0.0
- Initial release
- Start/Stop recording functionality
- Search with regex support
- Export to JSON
- Real-time message capture
- Local storage management
